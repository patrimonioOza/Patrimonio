package com.example.patrimonio2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class petroglifoDoOuteiroDoCorno : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_petroglifo_do_outeiro_do_corno)
    }
}