package com.example.patrimonio2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class marcoDaAgrela : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marco_da_agrela)
    }
}