package com.example.patrimonio2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class patrimonio_etnografico : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patrimonio_etnografico)
    }
}