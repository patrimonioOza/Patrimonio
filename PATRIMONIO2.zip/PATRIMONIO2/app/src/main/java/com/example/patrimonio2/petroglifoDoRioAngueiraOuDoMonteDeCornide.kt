package com.example.patrimonio2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class petroglifoDoRioAngueiraOuDoMonteDeCornide : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_petroglifo_do_rio_angueira_ou_do_monte_de_cornide)
    }
}