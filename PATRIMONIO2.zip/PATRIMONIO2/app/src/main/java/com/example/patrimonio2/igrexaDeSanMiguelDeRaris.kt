package com.example.patrimonio2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class igrexaDeSanMiguelDeRaris : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_igrexa_de_san_miguel_de_raris)
    }
}